import { Box, Toolbar, Typography } from "@mui/material";
import React from "react";
import Index from "../components/Main";
import Navbar from "../components/Navbar";

const Dashboard = () => {
    return (
        <div>
            
            <Index/>
            
        </div>
    );
}

export default Dashboard;